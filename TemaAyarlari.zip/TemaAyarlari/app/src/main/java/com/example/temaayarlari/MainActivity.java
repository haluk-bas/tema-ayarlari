package com.example.temaayarlari;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;

public class MainActivity extends AppCompatActivity {

    public SharedPreferences sharedPreferences;

    SharedPreferences.Editor editor=sharedPreferences.edit();


    RadioButton radioAcik;
    RadioButton radioKaranlik;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        int veri=sharedPreferences.getInt("tema",AppCompatDelegate.MODE_NIGHT_NO);



        if(veri == AppCompatDelegate.MODE_NIGHT_NO)
            radioAcik.setChecked(true);
        else
            radioKaranlik.setChecked(true);
    }


    public void onRadioClicked(View view){
        boolean checked=((RadioButton)view).isChecked();
        switch (view.getId()){
            case R.id.radioAcik:
                if(checked){
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                    editor.putInt("tema",AppCompatDelegate.MODE_NIGHT_NO);
                    editor.apply();
                }
                break;
            case R.id.radioKaranlik:
                if(checked){
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                    editor.putInt("tema",AppCompatDelegate.MODE_NIGHT_YES);
                    editor.apply();
                }
                break;
        }
    }

    protected void onDestroy() {
        sharedPreferences=null;
        super.onDestroy();
    }

}